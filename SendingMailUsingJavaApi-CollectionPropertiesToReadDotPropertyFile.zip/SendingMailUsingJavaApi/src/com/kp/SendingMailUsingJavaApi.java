package com.kp;


import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;

//import javax.activation.*; 

public class SendingMailUsingJavaApi {
	
	public static void main(String[] args) throws IOException {
		 // TODO Auto-generated method stub
		
		
		 String to = "pk455375@gmail.com";//change accordingly  
	     String from = "kpradeep455375@gmail.com"; //change accordingly  
	     String host = "192.168.2.138";//or IP address
		   
			  
	     //Get the session object  
	     Properties properties = System.getProperties();  
	     properties.setProperty("mail.smtp.host", host);  
	     Session session = Session.getDefaultInstance(properties);  
	  
	     //compose the message  
	     try{  
	        MimeMessage message = new MimeMessage(session);  
	        message.setFrom(new InternetAddress(from));  
	        message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	        message.setSubject("Test Mail Subject");  
	        message.setText("Hello, this is example of sending email  ");  
	  
	        // Send message  
	        Transport.send(message);  
	        System.out.println("message sent successfully....");  
	    }catch (MessagingException mex) {mex.printStackTrace();}
	}
	
	

}
