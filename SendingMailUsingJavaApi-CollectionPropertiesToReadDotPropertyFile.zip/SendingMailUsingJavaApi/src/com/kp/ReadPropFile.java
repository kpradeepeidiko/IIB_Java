package com.kp;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropFile {
	
	public static void main(String[] args) throws IOException{
		ReadPropFile obj = new ReadPropFile();
		obj.getFile();
	}
	
	private void getFile() throws IOException{
		Properties p=new Properties();
		p.load(new FileInputStream("resource/propertyFiles/emailProperties.properties"));	
		System.out.println("To = "   +   p.getProperty("to"));
		System.out.println("From = " + p.getProperty("from"));
		System.out.println("Host = " + p.getProperty("host"));
		
	}

}
