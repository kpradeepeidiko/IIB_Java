import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import org.apache.log4j.Logger;

public class javafixnode extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		

		MbMessage inMessage = inAssembly.getMessage();// getMESSAGE
		MbMessage inMessage1 = inAssembly.getGlobalEnvironment();// get
																	// environment
																	// MESSAGE
		

		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			
			MbMessage outMessage = new MbMessage();
			outAssembly = new MbMessageAssembly(inAssembly, inMessage1, inAssembly.getExceptionList(),outMessage);
			// ----------------------------------------------------------
			// Add user code below
			MbElement outroot = inMessage1.getRootElement();// ROOT
			MbElement parser = outroot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);// XMLNSC
			MbElement PARSER = parser.createElementAsLastChild(MbXMLNSC.FOLDER, " Result", null);
			MbElement root = inMessage.getRootElement();// INPUTROOT
			MbElement body = root.getLastChild();// DFDL
			MbElement ele = body.getFirstElementByPath("./javanodedfdl/body");
			while (ele != null) {
				String ID = ele.getFirstChild().getValueAsString();

				String FNAME = ele.getFirstChild().getNextSibling()
						.getValueAsString();

				String CITY = ele.getLastChild().getValueAsString();
				// ele = ele.getNextSibling();
				MbElement out1 = PARSER.createElementAsLastChild(
						MbElement.TYPE_NAME, "Data", null);
				out1.createElementAsLastChild(MbXMLNSC.FIELD, "ID", ID);
				out1.createElementAsLastChild(MbXMLNSC.FIELD, "FNAME", FNAME);
				out1.createElementAsLastChild(MbXMLNSC.FIELD, "CITY", CITY);
				ele = ele.getNextSibling();
			}

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal

		// outAssembly.getMessage().getRootElement().getLastChild().getPreviousSibling().delete();
		out.propagate(outAssembly);

	}

}
