# Flask Rest API

This code is a self explanatory code, I got from [impythonist](https://impythonist.wordpress.com/2015/07/12/build-an-api-under-30-lines-of-code-with-python-and-flask/) blog. The current repository,
helps in getting started with the basic REST API Development of Flask. PRs are welcome for the other REQUESTS. The sole existence of
this repo is to spread the information and no profit is made on it.
