package org.tutorials.kp.messangers.models;

//import javax.xml.bind.annotation.XmlRootElement;
//@XmlRootElement

public class Message {
	
	private int Id;
	private String ChatMessage;
	private String Author;
	
	public Message()
	{
		//super();
	}
	
	public Message(int id, String chatMessage, String author){
		this.Id = id;
		this.ChatMessage = chatMessage;
		this.Author = author;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	public String getChatMessage() {
		return ChatMessage;
	}

	public void setChatMessage(String chatMessage) {
		ChatMessage = chatMessage;
	}

	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	
	

}
