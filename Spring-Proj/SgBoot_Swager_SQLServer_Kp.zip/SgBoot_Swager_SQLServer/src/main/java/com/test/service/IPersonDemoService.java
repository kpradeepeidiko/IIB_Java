package com.test.service;



import java.util.List;
import com.test.model.PersonDemo;

public interface IPersonDemoService {
	
	List<PersonDemo> getAllPersons();

	PersonDemo getPersonById(int personId);

	
	boolean addPerson(PersonDemo personDemo);

	
	void updatePerson(PersonDemo personDemo);

	
	void deletePerson(int personId);

}
