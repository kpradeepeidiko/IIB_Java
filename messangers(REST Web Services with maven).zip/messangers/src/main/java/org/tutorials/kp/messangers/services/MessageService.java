package org.tutorials.kp.messangers.services;

import java.util.ArrayList;
import java.util.List;

import org.tutorials.kp.messangers.models.Message;

public class MessageService {
	
	public List<Message> getAllMessages(){
		
		Message msg1 = new Message(1,"Hello Pradeep","Asha");
		Message msg2 = new Message(2,"Hello Asha","Pradeep");
		Message msg3 = new Message(3,"Hello Mahija","Monica");
		
		List<Message> msgList = new ArrayList<Message>();
		msgList.add(msg1);
		msgList.add(msg2);
		msgList.add(msg3);
		
		return msgList;
	}

}
