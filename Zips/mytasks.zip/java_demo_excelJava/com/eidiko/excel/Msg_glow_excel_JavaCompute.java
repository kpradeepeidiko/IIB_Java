package com.eidiko.excel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.management.MBeanAttributeInfo;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class Msg_glow_excel_JavaCompute extends MbJavaComputeNode {
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		MbMessageAssembly outAssembly = null;
		try
		{
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below

			try 
			{

				MbElement inRoot = inMessage.getRootElement();
				MbElement XMLNSC = inRoot.getFirstElementByPath("XMLNSC");
				MbElement transferResponse = XMLNSC.getLastChild();

				MbElement listOfPersons = null;
				listOfPersons = transferResponse.getFirstChild();
				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet sheet = workbook.createSheet("Sample sheet");

				int i = 0;
				while (listOfPersons != null) {
					//int j = 0;/*this j values use for cell*/
					Row row = sheet.createRow(i);

					Cell cell1 = row.createCell(0);
					MbElement name = listOfPersons.getFirstElementByPath("first");
					String fname = name.getValueAsString();
					cell1.setCellValue(fname);

					Cell cell2 = row.createCell(1);
					MbElement last = listOfPersons.getFirstElementByPath("last");
					String flast = last.getValueAsString();
					cell2.setCellValue(flast);

					Cell cell3 = row.createCell(2);
					MbElement age = listOfPersons.getFirstElementByPath("age");
					String age1 = age.getValueAsString();
					cell3.setCellValue(age1);
					
					listOfPersons = listOfPersons.getNextSibling();
					i = i + 1;

				}// end of while loop with

				
				try 
				{
					FileOutputStream outP = new FileOutputStream(new File("C://Users//bandaru//Downloads//book.xlsx"));
					workbook.write(outP);
					outP.close();
					
					MbElement xmlnsc=outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME);
					MbElement result = xmlnsc.createElementAsLastChild(MbXMLNSC.FIELD,"result",null);
					String str= "xml to excel is  SUCCESS";
				result.createElementAsLastChild(MbElement.TYPE_NAME,"msg",str);
					
					
				} catch (FileNotFoundException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				
				
			} catch (Throwable t) {
				t.printStackTrace();
			}

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		outAssembly.getMessage().getRootElement().getLastChild().getPreviousSibling().delete();
		out.propagate(outAssembly);

	}

}
