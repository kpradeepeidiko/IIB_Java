import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import org.apache.log4j.Logger;

public class Fixmsgflow_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");
		final Logger logger = Logger.getLogger(Fixmsgflow_JavaCompute.class);
		if(logger.isDebugEnabled()){
			logger.debug("This is debugging mode ");
		}

		if(logger.isInfoEnabled()){
			logger.info("This is info mode ");
		}
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage inMessage1 = inAssembly.getGlobalEnvironment();//get environment MESSAGE
		MbMessage newEnv = new MbMessage(inMessage1);

		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			newEnv.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME, "data",null);
			outAssembly = new MbMessageAssembly(inAssembly,newEnv, inAssembly.getExceptionList(),outMessage);
			// ----------------------------------------------------------
			// Add user code below
			MbElement body = inMessage.getRootElement().getLastChild().getFirstChild().getFirstChild();
			
			String body_elem1 = body.getFirstElementByPath("body_elem1").getValueAsString();
			//System.out.println(empno);
			String body_elem2 = body.getFirstElementByPath("body_elem2").getNextSibling().getValueAsString();
			//System.out.println(empname);
			String body_elem3 = body.getFirstElementByPath("body_elem3").getNextSibling().getValueAsString();
			//System.out.println(empno);
			MbElement outroot=newEnv.getRootElement();
	        MbElement parser=outroot.createElementAsFirstChild(MbXMLNSC.PARSER_NAME);
	        MbElement out1=parser.createElementAsFirstChild(MbElement.TYPE_NAME,"Data",null);
	        MbElement out2=out1.createElementAsFirstChild(MbXMLNSC.FIELD,"body1",body_elem1);
	        MbElement out3=out2.createElementAfter(MbXMLNSC.FIELD,"body2",body_elem2);
	        MbElement out4=out3.createElementAfter(MbXMLNSC.FIELD,"body3",body_elem3);
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
