package com.test.doa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Repository;

import com.test.model.PersonDemo;


@Transactional
@Repository
@EntityScan("com.test.model")
public class PersonDemoDao implements IPersonDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<PersonDemo> getAllPersons() {
		// TODO Auto-generated method stub
		String hql = "SELECT pd FROM PersonDemo pd ORDER By pd.id";
		List<PersonDemo> td = new ArrayList<PersonDemo>();
		td = entityManager.createQuery(hql).getResultList();
		return td;
		
	}

	@Override
	public PersonDemo getPersonById(int personId) {
		// TODO Auto-generated method stub
		return (PersonDemo) entityManager.find(PersonDemo.class, personId);
	}

	@Override
	public void addPerson(PersonDemo personDemo) {
		// TODO Auto-generated method stub
		entityManager.persist(personDemo);
		
	}

	@Override
	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		entityManager.remove(getPersonById(personId));
		
	}

	@Override
	public void updatePerson(PersonDemo personDemo) {
		// TODO Auto-generated method stub
		PersonDemo pd = getPersonById(personDemo.getId());
		pd.setName(personDemo.getName());
		pd.setAge(personDemo.getAge());
		entityManager.flush();
		
	}

	@Override
	public boolean personExists(String name, int age) {
		// TODO Auto-generated method stub
		System.out.println(" In Dao for add");
		String hql = "SELECT pd FROM PersonDemo pd WHERE pd.name = ? and pd.age = ?";
		int count = entityManager.createQuery(hql).setParameter(1, name).setParameter(2, age).getResultList().size();
		System.out.println("count = " + count);
		return count > 0 ? true : false;
	}

}
