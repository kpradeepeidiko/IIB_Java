package com.eidiko.springbootstarter.registration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {
	
	@Autowired
	private RegistrationRepository registrationRepository;
	
	private List<Registration> registration=new ArrayList<>();
	
	public List<Registration> getAllEmployeeDetails(){
		
	List<Registration> registration=new ArrayList<>();
	return (List<Registration>) registrationRepository.findAll();
	
	}
	
	public Registration getEmployeeByempId(Integer empId){
		
		System.out.println("sefdjkg");
		//return registration.stream().filter(t -> t.getEmpId().equals(empId)).findFirst().get();
		return registrationRepository.getByEmpId(empId);
		
		}
	
	public void updateEmployeeByempId(Integer empId, Registration reg){
		registrationRepository.save(reg);
		
		/*for (int i=0; i<registration.size();i++){
			
			
				Registration r=registration.get(i);
				if(r.empId.equals(empId)){
					
					registration.set(i, reg);
					
					
				
				
			}
		}*/
		
		
		
		
		}
	
	public void addEmployee(Registration reg){
		if(registrationRepository.getByEmpId(reg.getEmpId()) == null)
		registrationRepository.save(reg);
		
		
		}
	
	public void deleteEmployeeByempId(Integer empId){
		
		 //registration.removeIf(t -> t.getEmpId().equals(empId));
		registrationRepository.deleteByEmpId(empId);
		
	}
		
		
}
