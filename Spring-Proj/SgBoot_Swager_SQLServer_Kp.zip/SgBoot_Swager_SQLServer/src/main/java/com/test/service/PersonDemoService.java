package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.doa.PersonDemoDao;
import com.test.model.PersonDemo;

@Service
public class PersonDemoService implements IPersonDemoService {
	
	@Autowired
	private PersonDemoDao pdao;

	@Override
	public List<PersonDemo> getAllPersons() {
		// TODO Auto-generated method stub
		System.out.println("In Service Method");
		return pdao.getAllPersons();
	}

	@Override
	public PersonDemo getPersonById(int personId) {
		// TODO Auto-generated method stub
		return pdao.getPersonById(personId);
	}

	@Override
	public boolean addPerson(PersonDemo personDemo) {
		// TODO Auto-generated method stub
		if(pdao.personExists(personDemo.getName(), personDemo.getAge()))
		{
			return false;
		}else {
			pdao.addPerson(personDemo);
			return true;
		}
		
	}

	@Override
	public void updatePerson(PersonDemo personDemo) {
		// TODO Auto-generated method stub
		pdao.updatePerson(personDemo);
		
	}

	@Override
	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		pdao.deletePerson(personId);
		
	}

}
