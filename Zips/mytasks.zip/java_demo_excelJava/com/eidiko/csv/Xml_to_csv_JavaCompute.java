package com.eidiko.csv;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbDFDL;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class Xml_to_csv_JavaCompute extends MbJavaComputeNode 
{

	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try
		{
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);

			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below

			MbElement inRoot = inMessage.getRootElement();
			MbElement xmlnsc = inRoot.getFirstElementByPath("XMLNSC");
			MbElement root 		=	xmlnsc.getFirstChild();
			MbElement body 		= null;
			body=root.getFirstChild();
			
			
			/*creating csv format*/
			MbElement parser =outMessage.getRootElement().createElementAsLastChild(MbDFDL.PARSER_NAME );
			MbElement csv=parser.createElementAsLastChild(MbElement.TYPE_NAME,"csv",null);
			
			while(body != null)
			{
				MbElement record=csv.createElementAsLastChild(MbElement.TYPE_NAME,"record",null);
				
				MbElement fname=body.getFirstElementByPath("fname");
				String value1= fname.getValueAsString();
				record.createElementAsLastChild(MbElement.TYPE_NAME,"fname",value1);
				
				MbElement lname=body.getFirstElementByPath("lname");
				String value2= lname.getValueAsString();
				record.createElementAsLastChild(MbElement.TYPE_NAME,"lname",value2);
				
				MbElement age=body.getFirstElementByPath("age");
				String value3= age.getValueAsString();
				record.createElementAsLastChild(MbElement.TYPE_NAME,"age",value3);
				body=body.getNextSibling();
			}
			
			// End of user code
			// ----------------------------------------------------------
		} 
		catch (MbException e) 
		{
			// Re-throw to allow Broker handling of MbException
			throw e;
		} 
		catch (RuntimeException e)
		{
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} 
		catch (Exception e) 
		{
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		outAssembly.getMessage().getRootElement().getLastChild().getPreviousSibling().delete();
		out.propagate(outAssembly);

	}

}
