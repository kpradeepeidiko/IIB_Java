package org.tutorials.kp.messangers.sampletest;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.tutorials.kp.messangers.models.Message;
import org.tutorials.kp.messangers.services.MessageService;

@Path("sampleMesg")
@Consumes(MediaType.APPLICATION_JSON) //To sepcify that it accepts json as request
@Produces(MediaType.APPLICATION_JSON) //To sepcify that it returns json as response
public class SampleMessage {
	
	MessageService mesgService = new MessageService();

	@GET
	public List<Message> listMessage()
	{
		return mesgService.getAllMessages();
	}
	
	
	@GET
	@Path("/{messageId}")
	public Message getMessage(@PathParam("messageId") int messageId)
	{
		
		if(messageId == 1){
			Message msg = new Message(1,"Hello Pradeep!!!", "Asha Latha");
			return msg;
		}
		else
		{
			Message msg = new Message(2,"Hello Asha!!!", "Pradeep");
			return msg;
		}
	}
	
	@POST
	public Response addMessage(Message message1, @Context UriInfo uriInfo){
		
		System.out.println("Absolute Path = " + uriInfo.getAbsolutePath()); // Print asolute path
		String newId = String.valueOf(message1.getId()); // Get Id form new message
		 
		//by using getAbsolutePathBuilder() you will get "absolutePath" and path() method will add the value to that path, then use build() method to build that url
		URI uri = uriInfo.getAbsolutePathBuilder().path(newId).build();  
		Message newMessageObject = new Message(message1.getId(), message1.getChatMessage(), message1.getAuthor());
		return Response.created(uri)
					   .status(Status.CREATED)
					   .entity(newMessageObject)
					   .header("name1", "Pradeep Asha")
					   .build();
	}
}
