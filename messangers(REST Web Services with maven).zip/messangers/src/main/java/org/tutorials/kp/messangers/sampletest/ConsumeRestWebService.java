package org.tutorials.kp.messangers.sampletest;

//import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ConsumeRestWebService {

	public static void main(String[] args) throws ClientProtocolException, IOException, UnsupportedOperationException, ParseException{
		// TODO Auto-generated method stub
		HttpClient client;
		client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet("http://localhost:8085/messangers/webapi/sampleMesg/1");
		HttpResponse response = client.execute(request);
		System.out.println(response.getEntity().getContent());
		/*BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		String line = " ";
		while((line = rd.readLine()) != null){
			System.out.println(line);
		}*/
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new InputStreamReader(response.getEntity().getContent()));
		JSONObject jsonObject = (JSONObject) obj;
		
		//Output REST Call: {"author":"Asha Latha","chatMessage":"Hello Pradeep!!!","id":1}
		
		//int id = String.valueOf((String) jsonObject.get("id"));
		String chatMessage = (String) jsonObject.get("chatMessage"); 
		String author = (String) jsonObject.get("author");
		System.out.println(" " +  chatMessage + " " + author);
	}

}
