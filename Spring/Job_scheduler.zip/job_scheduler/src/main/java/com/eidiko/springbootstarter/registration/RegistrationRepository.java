package com.eidiko.springbootstarter.registration;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface RegistrationRepository extends CrudRepository<Registration, Integer> {

	@Query("SELECT p FROM Registration p WHERE p.empId = :empId")
	public Registration getByEmpId(@Param("empId")int empId);
	
	@Modifying
    @Transactional
    public void deleteByEmpId(int empId);
}



