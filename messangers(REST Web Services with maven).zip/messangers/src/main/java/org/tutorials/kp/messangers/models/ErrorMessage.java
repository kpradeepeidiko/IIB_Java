package org.tutorials.kp.messangers.models;

public class ErrorMessage {
	
	private int ErrorCode;
	private String Documentation;
	private String ErrorMessage;
	
	public ErrorMessage()
	{
		
	}
	
	public ErrorMessage(int errorCode, String documentation, String errorMsg){
		this.ErrorCode = errorCode;
		this.ErrorMessage = errorMsg;
		this.Documentation = documentation;
	}
	
	public int getErrorCode() {
		return ErrorCode;
	}
	public void setErrorCode(int errorCode) {
		ErrorCode = errorCode;
	}
	public String getDocumentation() {
		return Documentation;
	}
	public void setDocumentation(String documentation) {
		Documentation = documentation;
	}
	public String getErrorMessage() {
		return ErrorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}
	
	

}
