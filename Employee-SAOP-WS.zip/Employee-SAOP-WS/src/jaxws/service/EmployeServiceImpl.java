package jaxws.service;

import jaxws.beans.Employee;



public class EmployeServiceImpl implements EmployeService{

	@Override
	public boolean addEmployee(Employee e) {
		// TODO Auto-generated method stub
		System.out.println("Add Employee Method");
		return false;
	}

	@Override
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		System.out.println("Delete Employee Method: " + id);
		return false;
	}

	@Override
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
		System.out.println("Get Employee Method: " + id);
		
		Employee e = new Employee();
		
		if (id == 1)
		{
			e.setId(1);
			e.setName("pradeep");
			e.setAge(25);
		}
		else
		{
			e.setId(2);
			e.setName("pradeep2");
			e.setAge(26);
		}
		
		return e;
	}

	@Override
	public Employee[] listEmployee() {
		// TODO Auto-generated method stub
		System.out.println("List Employee");
		
		Employee[] eList = new Employee[3];
		
		Employee e1 = new Employee();
		e1.setId(1);
		e1.setName("Pradeep1");
		e1.setAge(25);
		
		Employee e2 = new Employee();
		e2.setId(2);
		e2.setName("Pradeep2");
		e2.setAge(25);
		
		Employee e3 = new Employee();
		e3.setId(3);
		e3.setName("Pradeep3");
		e3.setAge(25);
		
		eList[0] = e1;
		eList[1] = e2;
		eList[2] = e3;
		
		System.out.println("List Employee Last");
		
		return eList;
	}

}
