package com.hari.excel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class Msg_glow_excel_JavaCompute1 extends MbJavaComputeNode
{
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		MbMessageAssembly outAssembly = null;
		try 
		{
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below

			ArrayList<String> firstNames = new ArrayList<String>();
			ArrayList<String> lastNames = new ArrayList<String>();
			ArrayList<String> ages = new ArrayList<String>();

			try 
			{

				MbElement inRoot = inMessage.getRootElement();
				MbElement XMLNSC = inRoot.getFirstElementByPath("XMLNSC");
				MbElement transferResponse = XMLNSC.getLastChild();

				MbElement listOfPersons = null;
				listOfPersons = transferResponse.getFirstChild();

		

				while (listOfPersons != null)
				{
					MbElement name = listOfPersons.getFirstElementByPath("first");
					String fname = name.getValueAsString();
					firstNames.add(fname);

					MbElement last = listOfPersons.getFirstElementByPath("last");
					String flast = last.getValueAsString();
					lastNames.add(flast);

					MbElement age = listOfPersons.getFirstElementByPath("age");
					String age1 = age.getValueAsString();
					ages.add(age1);
					listOfPersons = listOfPersons.getNextSibling();

				}// end of for loop with s var
			} 
			catch (Throwable t) 
			{
				t.printStackTrace();
			}

			
			  XSSFWorkbook workbook = new XSSFWorkbook();
			  XSSFSheet sheet = workbook.createSheet("Sample sheet"); 
			 
			  
			  Map<String, Object[]> data = new HashMap<String, Object[]>();
			  for(int i = 0; i < firstNames.size(); i++)
			  {
				  
				  data.put(i + "", new Object[] { firstNames.get(i).toString(),lastNames.get(i).toString(), ages.get(i).toString() });
			  }
			 
			 Set<String> keyset = data.keySet(); int rownum = 0;
			 for (String key : keyset)
			 { 
				 Row row = sheet.createRow(rownum++); 
				 Object[] objArr = data.get(key);
				 int cellnum = 0; 
				 for (Object obj : objArr) 
				 { 
					 Cell cell = row.createCell(cellnum++);
					 if (obj instanceof Date)
						 cell.setCellValue((Date) obj); 
					 else if (obj instanceof Boolean)
						 cell.setCellValue((Boolean) obj);
					 else if(obj instanceof String) 
						 cell.setCellValue((String) obj); 
					 else if(obj instanceof Double)
						 cell.setCellValue((Double) obj);
					 }
				 }
			 
			 try 
			 { 
				 FileOutputStream outP = new FileOutputStream(new File("C://Users//bandaru//Downloads//bookjava1.xlsx"));
			 workbook.write(outP);
			 outP.close(); //
			 MbElement xmlnsc=outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement result = xmlnsc.createElementAsLastChild(MbXMLNSC.FIELD,"result",null);
				String str= "xml to excel is  SUCCESS";
			result.createElementAsLastChild(MbElement.TYPE_NAME,"msg",str);
			 }
			 catch (FileNotFoundException e) 
			 {
				// TODO: handle exception
				 throw e;
			}
			 
			// End of user code
			// ----------------------------------------------------------
		} 
		catch (MbException e) 
		{
			// Re-throw to allow Broker handling of MbException
			throw e;
		}
		catch (RuntimeException e)
		{
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		}
		catch (Exception e)
		{
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		outAssembly.getMessage().getRootElement().getLastChild().getPreviousSibling().delete();
		out.propagate(outAssembly);

	}
}