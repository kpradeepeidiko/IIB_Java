package jaxws.service;

import java.rmi.RemoteException;
import java.util.ArrayList;

import jaxws.beans.Employee;

public class TestClient {
	
	public static void main(String[] args){
		EmployeServiceImplProxy proxy = new EmployeServiceImplProxy();
			
		try {
			ArrayList<Employee> eList = new ArrayList<Employee>();
			Employee[] emp = new Employee[3];
			emp =  proxy.listEmployee();
			int i;
			System.out.println("[] size: " + emp.length);
			for (Employee employee : emp) {
				eList.add(employee);
			}
			System.out.println("ArrayList Size: " + eList.size());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
