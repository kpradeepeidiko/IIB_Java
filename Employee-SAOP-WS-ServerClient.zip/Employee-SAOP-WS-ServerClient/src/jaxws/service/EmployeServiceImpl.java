/**
 * EmployeServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package jaxws.service;

public interface EmployeServiceImpl extends java.rmi.Remote {
    public boolean deleteEmployee(int id) throws java.rmi.RemoteException;
    public jaxws.beans.Employee getEmployee(int id) throws java.rmi.RemoteException;
    public jaxws.beans.Employee[] listEmployee() throws java.rmi.RemoteException;
    public boolean addEmployee(jaxws.beans.Employee e) throws java.rmi.RemoteException;
}
