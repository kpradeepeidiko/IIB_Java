package com.eidiko.xml;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

public class Msg_flow_Excel_to_xml_JavaCompute extends MbJavaComputeNode {
	private static final String FILE_NAME = "C://Users//bandaru//Downloads//bookjava1.xlsx";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below

			// try {
			MbElement xmlnsc = outMessage.getRootElement()
					.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement body = xmlnsc.createElementAsLastChild(MbXMLNSC.FOLDER,
					"body", null);

			FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();

			while (iterator.hasNext()) {

				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();
				int count = 1;
				MbElement result = body.createElementAsLastChild(
						MbElement.TYPE_NAME, "result", null);
				while (cellIterator.hasNext()) {
					
					Cell currentCell = cellIterator.next();

					// getCellTypeEnum shown as deprecated for version 3.15
					// getCellTypeEnum ill be renamed to getCellType starting
					// from version 4.0

					if (count == 1) {
						if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
							String R1 = currentCell.getStringCellValue();
							result.createElementAsLastChild(MbXMLNSC.FIELD,
									"fname", R1);
						}
					} else if (count == 2) {
						if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
							String R2 = currentCell.getStringCellValue();
							result.createElementAsLastChild(MbXMLNSC.FIELD,
									"lname", R2);
						}
					} else  if (count == 3){
						 if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) 
						{
					String R3 =  currentCell.getStringCellValue();
						result.createElementAsLastChild(MbXMLNSC.FIELD, "age",
								R3);
						}
					}
					count = count + 1;
				}
				// System.out.println();
			}
			/*
			 * } catch (FileNotFoundException e) { e.printStackTrace(); } catch
			 * (IOException e) { e.printStackTrace(); }
			 */

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		outAssembly.getMessage().getRootElement().getLastChild()
				.getPreviousSibling().delete();
		out.propagate(outAssembly);

	}

}
