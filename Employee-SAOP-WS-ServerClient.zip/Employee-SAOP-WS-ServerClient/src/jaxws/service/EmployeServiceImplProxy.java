package jaxws.service;

public class EmployeServiceImplProxy implements jaxws.service.EmployeServiceImpl {
  private String _endpoint = null;
  private jaxws.service.EmployeServiceImpl employeServiceImpl = null;
  
  public EmployeServiceImplProxy() {
    _initEmployeServiceImplProxy();
  }
  
  public EmployeServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initEmployeServiceImplProxy();
  }
  
  private void _initEmployeServiceImplProxy() {
    try {
      employeServiceImpl = (new jaxws.service.EmployeServiceImplServiceLocator()).getEmployeServiceImpl();
      if (employeServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)employeServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)employeServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (employeServiceImpl != null)
      ((javax.xml.rpc.Stub)employeServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public jaxws.service.EmployeServiceImpl getEmployeServiceImpl() {
    if (employeServiceImpl == null)
      _initEmployeServiceImplProxy();
    return employeServiceImpl;
  }
  
  public boolean deleteEmployee(int id) throws java.rmi.RemoteException{
    if (employeServiceImpl == null)
      _initEmployeServiceImplProxy();
    return employeServiceImpl.deleteEmployee(id);
  }
  
  public jaxws.beans.Employee getEmployee(int id) throws java.rmi.RemoteException{
    if (employeServiceImpl == null)
      _initEmployeServiceImplProxy();
    return employeServiceImpl.getEmployee(id);
  }
  
  public jaxws.beans.Employee[] listEmployee() throws java.rmi.RemoteException{
    if (employeServiceImpl == null)
      _initEmployeServiceImplProxy();
    return employeServiceImpl.listEmployee();
  }
  
  public boolean addEmployee(jaxws.beans.Employee e) throws java.rmi.RemoteException{
    if (employeServiceImpl == null)
      _initEmployeServiceImplProxy();
    return employeServiceImpl.addEmployee(e);
  }
  
  
}