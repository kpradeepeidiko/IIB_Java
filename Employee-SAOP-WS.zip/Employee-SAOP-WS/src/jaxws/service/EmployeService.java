package jaxws.service;

import jaxws.beans.Employee;


public interface EmployeService {
	
	
	public boolean addEmployee(Employee e);
	
	
	public boolean deleteEmployee(int id);
	
	
	public Employee getEmployee(int id);
	
	
	public Employee[] listEmployee();
	
	

}
