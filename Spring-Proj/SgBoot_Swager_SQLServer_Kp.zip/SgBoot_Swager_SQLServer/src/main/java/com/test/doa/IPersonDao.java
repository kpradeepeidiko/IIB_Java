package com.test.doa;

import java.util.List;

import com.test.model.PersonDemo;

public interface IPersonDao {
	
	List<PersonDemo> getAllPersons();
	
	PersonDemo getPersonById(int personId);
	
	void addPerson(PersonDemo personDemo);
	
	void deletePerson(int personId);
	
	void updatePerson(PersonDemo personDemo);
	
	boolean personExists(String name, int age);

}
