package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.test.service.PersonDemoService;
import com.test.model.*;
import java.util.List;

@RestController
@RequestMapping("/person")
public class PersonDemoController {
	
	@Autowired
	private PersonDemoService pds;
	
	
	@GetMapping("/all")
	public ResponseEntity<List<PersonDemo>> getAllPersons() {
		System.out.println("In Controller Method");
		List<PersonDemo> list = pds.getAllPersons();
		return new ResponseEntity<List<PersonDemo>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/{personId}")
	public ResponseEntity<PersonDemo> getPersonById(@PathVariable("personId") int id){
		PersonDemo personDemo = pds.getPersonById(id);
		return new ResponseEntity<PersonDemo>(personDemo, HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Void> addPerson(@RequestBody PersonDemo personDemo, UriComponentsBuilder builder)
	{
		boolean flag = pds.addPerson(personDemo);
		if(flag == false)
		{
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/person/{personId}").buildAndExpand(personDemo.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@PutMapping("/update")
	public ResponseEntity<PersonDemo> updatePerson(@RequestBody PersonDemo personDemo)
	{
		pds.updatePerson(personDemo);
		return new ResponseEntity<PersonDemo>(personDemo, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{personId}")
	public ResponseEntity<Void> deletePerson(@PathVariable("personId") int id)
	{
		pds.deletePerson(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	

}
