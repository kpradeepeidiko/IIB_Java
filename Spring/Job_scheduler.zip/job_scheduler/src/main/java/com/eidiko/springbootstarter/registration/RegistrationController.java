package com.eidiko.springbootstarter.registration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping("/employee")
public class RegistrationController {
	
	@Autowired
	private RegistrationService registrationservice;
	
	
	@RequestMapping(value="/getAllEmployeeDetails", method=RequestMethod.GET)
	public List<Registration> getAllUserDetails(){
		
		return registrationservice.getAllEmployeeDetails();
	}
	
	@RequestMapping(value="/getEmployee/{empId}", method=RequestMethod.GET)
	public Registration getEmployeeByempId(@PathVariable Integer empId){
		return registrationservice.getEmployeeByempId(empId);
		
	}
	
	
	@RequestMapping(value="/addEmployee", method=RequestMethod.POST)
	public void addEmployee(@RequestBody Registration registration){
		registrationservice.addEmployee(registration);
	}
	
	@RequestMapping(value="/updateEmployee/{empId}", method=RequestMethod.PUT)
	public void updateEmployeeByempId(@PathVariable Integer empId, @RequestBody Registration registration ){
		registrationservice.updateEmployeeByempId(empId, registration);
		
		
	}
	@RequestMapping(value="/deleteEmployee/{empId}", method=RequestMethod.DELETE)
	public void deleteEmployeeByempId(@PathVariable Integer empId){
		registrationservice.deleteEmployeeByempId(empId);
		
		
	}

}
