package com.eidiko.springbootstarter.registration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(
		   name = "registration", 
		   uniqueConstraints = {@UniqueConstraint(columnNames = {"empId"})}
		)
public class Registration {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer Id;
	
	@Column
	String name;
	
	@Column
	String gender;
	
	@Column
	String dateOfBirth;
	
	@Column
	Integer empId;
	
	@Column
	String username;
	
	@Column
	String emailId;
	
	@Column
	String status;
	
	@Column
	String role;

	
	public Registration() {
		
		
	}
	
	public Registration( String name, String gender, String dateOfBirth, Integer empId, String username,
			String emailId, String status, String role) {
		super();
		
		this.name = name;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.empId = empId;
		this.username = username;
		this.emailId = emailId;
		this.status = status;
		this.role = role;
	}
	/*public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}*/
	public Integer getId() {
		return Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getdateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
