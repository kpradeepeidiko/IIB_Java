package com.eidiko.springbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSchedulerApp {

	public static void main(String[] args) {

		SpringApplication.run(JobSchedulerApp.class, args);

	}

}
